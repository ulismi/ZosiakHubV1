ZosiakHub - Executor

Jak używać:
1. Wrzuć pliki `ZosiakHub.lua` oraz `scripts.json` do folderu z exploitorem.
2. Uruchom exploita i załaduj skrypt `ZosiakHub.lua`.
3. Wybierz skrypt z listy lub użyj wyszukiwarki.
4. Możesz edytować `scripts.json`, aby dodać własne skrypty.

Miłej zabawy!
