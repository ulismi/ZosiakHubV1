-- Tworzenie GUI
local ZosiakHub = Instance.new("ScreenGui")
local MainFrame = Instance.new("Frame")
local Title = Instance.new("TextLabel")
local SearchBox = Instance.new("TextBox")
local ScriptsList = Instance.new("ScrollingFrame")
local SafeLabel = Instance.new("TextLabel")
local DiscordButton = Instance.new("TextButton")
local GithubButton = Instance.new("TextButton")

-- Ustawienia GUI
ZosiakHub.Name = "ZosiakHub"
ZosiakHub.Parent = game.CoreGui

MainFrame.Name = "MainFrame"
MainFrame.Parent = ZosiakHub
MainFrame.Size = UDim2.new(0, 400, 0, 500)
MainFrame.Position = UDim2.new(0.5, -200, 0.5, -250)
MainFrame.BackgroundColor3 = Color3.fromRGB(50, 50, 50)

Title.Name = "Title"
Title.Parent = MainFrame
Title.Size = UDim2.new(1, 0, 0, 50)
Title.Text = "ZosiakHub - Executor"
Title.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Title.TextColor3 = Color3.fromRGB(255, 255, 255)
Title.Font = Enum.Font.SourceSansBold
Title.TextSize = 20

SearchBox.Name = "SearchBox"
SearchBox.Parent = MainFrame
SearchBox.Size = UDim2.new(0.9, 0, 0, 30)
SearchBox.Position = UDim2.new(0.05, 0, 0.12, 0)
SearchBox.PlaceholderText = "Search..."
SearchBox.Text = ""

ScriptsList.Name = "ScriptsList"
ScriptsList.Parent = MainFrame
ScriptsList.Size = UDim2.new(0.9, 0, 0.6, 0)
ScriptsList.Position = UDim2.new(0.05, 0, 0.2, 0)
ScriptsList.CanvasSize = UDim2.new(0, 0, 2, 0)

SafeLabel.Name = "SafeLabel"
SafeLabel.Parent = MainFrame
SafeLabel.Size = UDim2.new(1, 0, 0, 30)
SafeLabel.Position = UDim2.new(0, 0, 0.82, 0)
SafeLabel.Text = "Safe?: Safe"
SafeLabel.TextColor3 = Color3.fromRGB(0, 255, 0)
SafeLabel.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
SafeLabel.Font = Enum.Font.SourceSans
SafeLabel.TextSize = 18

DiscordButton.Name = "DiscordButton"
DiscordButton.Parent = MainFrame
DiscordButton.Size = UDim2.new(0.9, 0, 0, 30)
DiscordButton.Position = UDim2.new(0.05, 0, 0.9, 0)
DiscordButton.Text = "Discord"
DiscordButton.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
DiscordButton.TextColor3 = Color3.fromRGB(255, 255, 255)
DiscordButton.MouseButton1Click:Connect(function()
    setclipboard("https://discord.gg/TwojLink")
    print("Discord link copied!")
end)

GithubButton.Name = "GithubButton"
GithubButton.Parent = MainFrame
GithubButton.Size = UDim2.new(0.9, 0, 0, 30)
GithubButton.Position = UDim2.new(0.05, 0, 0.95, 0)
GithubButton.Text = "Github"
GithubButton.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
GithubButton.TextColor3 = Color3.fromRGB(255, 255, 255)
GithubButton.MouseButton1Click:Connect(function()
    setclipboard("https://github.com/TwojRepo")
    print("Github link copied!")
end)

-- Wczytywanie skryptów z pliku JSON
local HttpService = game:GetService("HttpService")
local ScriptsData = HttpService:JSONDecode(readfile("scripts.json"))

local function addScript(name, scriptCode)
    local scriptButton = Instance.new("TextButton")
    scriptButton.Parent = ScriptsList
    scriptButton.Size = UDim2.new(1, 0, 0, 30)
    scriptButton.Text = name
    scriptButton.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
    scriptButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    scriptButton.MouseButton1Click:Connect(function()
        loadstring(scriptCode)()
    end)
end

for _, script in pairs(ScriptsData) do
    addScript(script.name, script.code)
end

-- Wyszukiwarka skryptów
SearchBox:GetPropertyChangedSignal("Text"):Connect(function()
    for _, button in pairs(ScriptsList:GetChildren()) do
        if button:IsA("TextButton") then
            if string.find(string.lower(button.Text), string.lower(SearchBox.Text)) then
                button.Visible = true
            else
                button.Visible = false
            end
        end
    end
end)
